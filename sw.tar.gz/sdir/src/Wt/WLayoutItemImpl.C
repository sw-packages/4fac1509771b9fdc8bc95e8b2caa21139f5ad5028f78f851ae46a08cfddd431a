/*
 * Copyright (C) 2016 Emweb bvba, Kessel-Lo, Belgium.
 *
 * See the LICENSE file for terms of use.
 */

#include "Wt/WLayoutItemImpl.h"

namespace Wt {

WLayoutItemImpl::~WLayoutItemImpl()
{ }

}
